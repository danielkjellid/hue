/* ==========================================================================
   Hue Design System — gallery behaviour
   --------------------------------------------------------------------------
   Vanilla JS so the specimens are actually operable (keyboard included).
   In the real library this behaviour is Alpine.js — each handler below maps
   to a directive, noted in the component's page notes.
   ========================================================================== */

(function () {
  "use strict";

  /* ---- theme ------------------------------------------------------------ */

  var THEME_KEY = "hue-ds-theme";

  function systemTheme() {
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }

  function applyTheme(choice) {
    var resolved = choice === "system" ? systemTheme() : choice;
    document.documentElement.setAttribute("data-theme", resolved);
    document.querySelectorAll("[data-theme-option]").forEach(function (btn) {
      btn.setAttribute("aria-pressed", String(btn.dataset.themeOption === choice));
    });
  }

  function initTheme() {
    var stored = localStorage.getItem(THEME_KEY) || "system";
    applyTheme(stored);
    document.querySelectorAll("[data-theme-option]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        var choice = btn.dataset.themeOption;
        localStorage.setItem(THEME_KEY, choice);
        applyTheme(choice);
      });
    });
    window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", function () {
      if ((localStorage.getItem(THEME_KEY) || "system") === "system") applyTheme("system");
    });
  }

  /* ---- tabs (roving tabindex, WAI-ARIA tabs pattern) -------------------- */

  function initTabs() {
    document.querySelectorAll("[data-tabs]").forEach(function (root) {
      var tabs = Array.prototype.slice.call(root.querySelectorAll('[role="tab"]'));
      if (!tabs.length) return;

      function select(tab) {
        tabs.forEach(function (t) {
          var on = t === tab;
          t.setAttribute("aria-selected", String(on));
          t.tabIndex = on ? 0 : -1;
          var panel = document.getElementById(t.getAttribute("aria-controls"));
          if (panel) panel.hidden = !on;
        });
      }

      tabs.forEach(function (tab, i) {
        tab.addEventListener("click", function () { select(tab); });
        tab.addEventListener("keydown", function (e) {
          var next = null;
          if (e.key === "ArrowRight") next = tabs[(i + 1) % tabs.length];
          else if (e.key === "ArrowLeft") next = tabs[(i - 1 + tabs.length) % tabs.length];
          else if (e.key === "Home") next = tabs[0];
          else if (e.key === "End") next = tabs[tabs.length - 1];
          if (next) { e.preventDefault(); select(next); next.focus(); }
        });
      });
    });
  }

  /* ---- accordion -------------------------------------------------------- */

  function initAccordions() {
    document.querySelectorAll("[data-accordion]").forEach(function (root) {
      var single = root.dataset.accordion === "single";
      root.querySelectorAll(".accordion__trigger").forEach(function (trigger) {
        trigger.addEventListener("click", function () {
          var open = trigger.getAttribute("aria-expanded") === "true";
          if (single && !open) {
            root.querySelectorAll('.accordion__trigger[aria-expanded="true"]').forEach(function (other) {
              other.setAttribute("aria-expanded", "false");
              document.getElementById(other.getAttribute("aria-controls")).hidden = true;
            });
          }
          trigger.setAttribute("aria-expanded", String(!open));
          document.getElementById(trigger.getAttribute("aria-controls")).hidden = open;
        });
      });
    });
  }

  /* ---- focus trap (shared by dialog / drawer / command) ----------------- */

  var FOCUSABLE = 'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';

  function trapFocus(container, e) {
    var items = Array.prototype.slice.call(container.querySelectorAll(FOCUSABLE))
      .filter(function (el) { return el.offsetParent !== null; });
    if (!items.length) return;
    var first = items[0], last = items[items.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }

  /* ---- overlays (dialog, drawer, command) ------------------------------- */

  var openOverlay = null;
  var lastTrigger = null;

  function closeOverlay() {
    if (!openOverlay) return;
    openOverlay.hidden = true;
    openOverlay = null;
    document.body.style.overflow = "";
    if (lastTrigger) { lastTrigger.focus(); lastTrigger = null; }
  }

  function showOverlay(el, trigger) {
    closeOverlay();
    lastTrigger = trigger || null;
    el.hidden = false;
    openOverlay = el;
    document.body.style.overflow = "hidden";
    var focusTarget = el.querySelector("[data-autofocus]") || el.querySelector(FOCUSABLE);
    if (focusTarget) focusTarget.focus();
  }

  function initOverlays() {
    document.querySelectorAll("[data-overlay-open]").forEach(function (trigger) {
      trigger.addEventListener("click", function () {
        var el = document.getElementById(trigger.dataset.overlayOpen);
        if (el) showOverlay(el, trigger);
      });
    });
    document.querySelectorAll("[data-overlay-close]").forEach(function (btn) {
      btn.addEventListener("click", closeOverlay);
    });
    document.addEventListener("keydown", function (e) {
      if (!openOverlay) return;
      if (e.key === "Escape") { e.preventDefault(); closeOverlay(); }
      else if (e.key === "Tab") trapFocus(openOverlay, e);
    });
    // Cmd/Ctrl+K opens the command palette when the page has one.
    document.addEventListener("keydown", function (e) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        var palette = document.getElementById("command-palette");
        if (palette) { e.preventDefault(); showOverlay(palette, document.activeElement); }
      }
    });
  }

  /* ---- popovers & dropdown menus ---------------------------------------- */

  function closeAllPoppers(except) {
    document.querySelectorAll("[data-popper]").forEach(function (root) {
      if (root === except) return;
      var trigger = root.querySelector("[data-popper-trigger]");
      var panel = root.querySelector("[data-popper-panel]");
      if (trigger) trigger.setAttribute("aria-expanded", "false");
      if (panel) panel.hidden = true;
    });
  }

  // "shift" middleware: an anchored panel that would leave the viewport slides
  // back inside it (16px margin) instead of forcing a horizontal scrollbar.
  function shiftIntoViewport(panel) {
    panel.style.marginInlineStart = "";
    var r = panel.getBoundingClientRect();
    var vw = document.documentElement.clientWidth;
    var overflowRight = r.right - (vw - 16);
    var overflowLeft = 16 - r.left;
    if (overflowRight > 0) panel.style.marginInlineStart = (-overflowRight) + "px";
    else if (overflowLeft > 0) panel.style.marginInlineStart = overflowLeft + "px";
  }

  function initPoppers() {
    document.querySelectorAll("[data-popper]").forEach(function (root) {
      var trigger = root.querySelector("[data-popper-trigger]");
      var panel = root.querySelector("[data-popper-panel]");
      if (!trigger || !panel) return;

      trigger.addEventListener("click", function (e) {
        e.stopPropagation();
        var open = trigger.getAttribute("aria-expanded") === "true";
        closeAllPoppers(root);
        trigger.setAttribute("aria-expanded", String(!open));
        panel.hidden = open;
        if (!open) {
          shiftIntoViewport(panel);
          var first = panel.querySelector(FOCUSABLE);
          if (first) first.focus();
        }
      });

      panel.addEventListener("keydown", function (e) {
        var items = Array.prototype.slice.call(panel.querySelectorAll('.menu__item:not([aria-disabled="true"]),.listbox__option'));
        var idx = items.indexOf(document.activeElement);
        if (e.key === "Escape") { e.preventDefault(); trigger.setAttribute("aria-expanded", "false"); panel.hidden = true; trigger.focus(); }
        else if (e.key === "ArrowDown" && items.length) { e.preventDefault(); items[(idx + 1) % items.length].focus(); }
        else if (e.key === "ArrowUp" && items.length) { e.preventDefault(); items[(idx - 1 + items.length) % items.length].focus(); }
      });

      panel.addEventListener("click", function (e) { e.stopPropagation(); });
      trigger.addEventListener("keydown", function (e) {
        if (e.key === "Escape" && trigger.getAttribute("aria-expanded") === "true") {
          e.preventDefault(); trigger.setAttribute("aria-expanded", "false"); panel.hidden = true;
        }
      });
    });

    document.addEventListener("click", function () { closeAllPoppers(null); });
  }

  /* ---- custom select ---------------------------------------------------- */

  function initSelects() {
    document.querySelectorAll("[data-select]").forEach(function (root) {
      var valueEl = root.querySelector(".select-trigger__value");
      root.querySelectorAll(".listbox__option").forEach(function (option) {
        option.addEventListener("click", function () {
          root.querySelectorAll(".listbox__option").forEach(function (o) { o.setAttribute("aria-selected", "false"); });
          option.setAttribute("aria-selected", "true");
          if (valueEl) {
            valueEl.textContent = option.dataset.label || option.textContent.trim();
            valueEl.classList.remove("select-trigger__value--placeholder");
          }
          closeAllPoppers(null);
          var trigger = root.querySelector("[data-popper-trigger]");
          if (trigger) trigger.focus();
        });
      });
    });
  }

  /* ---- combobox filtering ----------------------------------------------- */

  function initComboboxes() {
    document.querySelectorAll("[data-combobox]").forEach(function (root) {
      var input = root.querySelector(".combobox__search input");
      var empty = root.querySelector("[data-combobox-empty]");
      if (!input) return;
      input.addEventListener("input", function () {
        var q = input.value.trim().toLowerCase();
        var shown = 0;
        root.querySelectorAll(".listbox__option").forEach(function (option) {
          var match = option.textContent.toLowerCase().indexOf(q) !== -1;
          option.hidden = !match;
          if (match) shown++;
        });
        root.querySelectorAll(".listbox__group-label").forEach(function (label) {
          var group = label.parentElement;
          var any = Array.prototype.slice.call(group.querySelectorAll(".listbox__option"))
            .some(function (o) { return !o.hidden; });
          label.hidden = !any;
        });
        if (empty) empty.hidden = shown !== 0;
      });
    });
  }

  /* ---- command palette filtering + arrow nav ---------------------------- */

  function initCommand() {
    document.querySelectorAll("[data-command]").forEach(function (root) {
      var input = root.querySelector(".command__input");
      var empty = root.querySelector("[data-command-empty]");
      if (!input) return;

      function visibleItems() {
        return Array.prototype.slice.call(root.querySelectorAll(".command__item"))
          .filter(function (i) { return !i.hidden; });
      }

      var list = root.querySelector(".command__list");
      function setActive(item) {
        root.querySelectorAll(".command__item").forEach(function (i) { i.dataset.active = "false"; });
        if (!item) { input.removeAttribute("aria-activedescendant"); return; }
        item.dataset.active = "true";
        if (item.id) input.setAttribute("aria-activedescendant", item.id);
        // Keep the active row visible without scrollIntoView (which scrolls ancestors too).
        if (list) {
          var top = item.offsetTop - list.offsetTop, bottom = top + item.offsetHeight;
          if (top < list.scrollTop) list.scrollTop = top;
          else if (bottom > list.scrollTop + list.clientHeight) list.scrollTop = bottom - list.clientHeight;
        }
      }
      function run(item) {
        var action = item.dataset.commandAction || "";
        var trigger = lastTrigger;
        closeOverlay();
        if (action === "theme") {
          var next = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
          localStorage.setItem(THEME_KEY, next); applyTheme(next);
        } else if (action.indexOf("open:") === 0) {
          var target = document.getElementById(action.slice(5));
          if (target) showOverlay(target, trigger);
        }
      }
      root.querySelectorAll(".command__item[role='option']").forEach(function (item) {
        item.addEventListener("click", function () { run(item); });
        item.addEventListener("mousemove", function () { if (item.dataset.active !== "true") setActive(item); });
      });

      input.addEventListener("input", function () {
        var q = input.value.trim().toLowerCase();
        var shown = 0;
        root.querySelectorAll(".command__item").forEach(function (item) {
          var match = item.textContent.toLowerCase().indexOf(q) !== -1;
          item.hidden = !match;
          if (match) shown++;
        });
        root.querySelectorAll(".command__group").forEach(function (group) {
          group.hidden = !Array.prototype.slice.call(group.querySelectorAll(".command__item"))
            .some(function (i) { return !i.hidden; });
        });
        if (empty) empty.hidden = shown !== 0;
        setActive(visibleItems()[0]);
      });

      input.addEventListener("keydown", function (e) {
        var items = visibleItems();
        if (!items.length) return;
        var idx = items.findIndex(function (i) { return i.dataset.active === "true"; });
        if (e.key === "ArrowDown") { e.preventDefault(); setActive(items[(idx + 1) % items.length]); }
        else if (e.key === "ArrowUp") { e.preventDefault(); setActive(items[(idx - 1 + items.length) % items.length]); }
        else if (e.key === "Enter" && idx > -1) { e.preventDefault(); run(items[idx]); }
      });
    });
  }

  /* ---- toasts ----------------------------------------------------------- */

  var TOAST_ICONS = {
    success: '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>',
    danger: '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M15 9l-6 6M9 9l6 6"/></svg>',
    info: '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 16v-4M12 8h.01"/></svg>'
  };

  function initToasts() {
    var region = document.getElementById("toast-region");
    if (!region) return;
    document.querySelectorAll("[data-toast]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        var kind = btn.dataset.toast;
        var el = document.createElement("div");
        el.className = "toast toast--" + kind;
        // The region itself is aria-live="polite" (present before injection).
        // Errors are mirrored into the persistent role="alert" announcer.
        if (kind === "danger") {
          var announcer = document.getElementById("toast-announcer");
          if (announcer) { announcer.textContent = ""; announcer.textContent = btn.dataset.toastTitle + (btn.dataset.toastBody ? ". " + btn.dataset.toastBody : ""); }
        }
        el.innerHTML =
          '<span class="toast__icon">' + (TOAST_ICONS[kind] || TOAST_ICONS.info) + "</span>" +
          '<div class="toast__content"><div class="toast__title">' + btn.dataset.toastTitle + "</div>" +
          (btn.dataset.toastBody ? '<div class="toast__description">' + btn.dataset.toastBody + "</div>" : "") +
          "</div>" +
          '<button class="alert__close" aria-label="Dismiss"><svg class="icon icon--sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg></button>';
        region.appendChild(el);

        var timer = setTimeout(dismiss, 5200);
        function dismiss() {
          clearTimeout(timer);
          el.classList.add("toast--leaving");
          setTimeout(function () { el.remove(); }, 200);
        }
        // WCAG 2.2.1 — pause the auto-dismiss on hover and on focus.
        el.addEventListener("mouseenter", function () { clearTimeout(timer); });
        el.addEventListener("mouseleave", function () { timer = setTimeout(dismiss, 2600); });
        el.addEventListener("focusin", function () { clearTimeout(timer); });
        el.addEventListener("focusout", function (e) { if (!el.contains(e.relatedTarget)) timer = setTimeout(dismiss, 2600); });
        el.querySelector(".alert__close").addEventListener("click", dismiss);
      });
    });
  }

  /* ---- sliders (paint the filled track on WebKit) ----------------------- */

  function initSliders() {
    document.querySelectorAll(".slider").forEach(function (slider) {
      function paint() {
        var min = Number(slider.min || 0), max = Number(slider.max || 100);
        var pct = ((Number(slider.value) - min) / (max - min)) * 100;
        slider.style.setProperty("--slider-fill", pct + "%");
        var out = slider.closest(".ds-col, .slider-row, .field");
        var display = out && out.querySelector("[data-slider-value]");
        if (display) display.textContent = (slider.dataset.prefix || "") + slider.value + (slider.dataset.suffix || "");
      }
      slider.addEventListener("input", paint);
      paint();
    });
  }

  /* ---- dismissible alerts ----------------------------------------------- */

  function initDismiss() {
    document.querySelectorAll("[data-dismiss]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        var target = btn.closest(".alert");
        if (!target) return;
        // Removing the focused element drops focus to <body>; hand it to the
        // next alert's dismiss, or the enclosing section heading.
        var next = target.nextElementSibling && target.nextElementSibling.querySelector("[data-dismiss]");
        var heading = target.closest("section") && target.closest("section").querySelector("h2");
        target.remove();
        var to = next || heading;
        if (to) { if (!to.hasAttribute("tabindex") && to.tagName !== "BUTTON") to.tabIndex = -1; to.focus(); }
      });
    });
  }

  /* ---- confirmation gates (type-to-confirm, accept-to-continue) --------- */

  function initConfirmGates() {
    document.querySelectorAll("[data-confirm-value]").forEach(function (input) {
      var target = document.getElementById(input.dataset.confirmTarget);
      if (!target) return;
      function check() { target.disabled = input.value.trim().toLowerCase() !== input.dataset.confirmValue.toLowerCase(); }
      input.addEventListener("input", check); check();
    });
    document.querySelectorAll("[data-enables]").forEach(function (cb) {
      var target = document.getElementById(cb.dataset.enables);
      if (!target) return;
      function check() { target.disabled = !cb.checked; }
      cb.addEventListener("change", check); check();
    });
  }

  /* ---- tooltips: Escape dismisses (WCAG 1.4.13) -------------------------- */

  function initTooltips() {
    document.addEventListener("keydown", function (e) {
      if (e.key !== "Escape") return;
      document.querySelectorAll(".tt:hover, .tt:focus-within").forEach(function (tt) { tt.classList.add("is-dismissed"); });
    });
    document.querySelectorAll(".tt").forEach(function (tt) {
      tt.addEventListener("mouseleave", function () { tt.classList.remove("is-dismissed"); });
      tt.addEventListener("focusout", function (e) { if (!tt.contains(e.relatedTarget)) tt.classList.remove("is-dismissed"); });
    });
  }

  /* ---- checkbox tri-state demo ------------------------------------------ */

  function initIndeterminate() {
    document.querySelectorAll("[data-indeterminate]").forEach(function (cb) { cb.indeterminate = true; });
  }

  /* ---- in-page nav highlighting ----------------------------------------- */

  function initScrollSpy() {
    var links = Array.prototype.slice.call(document.querySelectorAll(".ds-navlink[href^='#']"));
    if (!links.length) return;
    var map = {};
    links.forEach(function (l) { map[l.getAttribute("href").slice(1)] = l; });

    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        links.forEach(function (l) { l.removeAttribute("aria-current"); });
        var link = map[entry.target.id];
        if (link) link.setAttribute("aria-current", "true");
      });
    }, { rootMargin: "-70px 0px -72% 0px" });

    Object.keys(map).forEach(function (id) {
      var el = document.getElementById(id);
      if (el) observer.observe(el);
    });
  }

  /* ---- boot ------------------------------------------------------------- */

  function boot() {
    initTheme();
    initTabs();
    initAccordions();
    initOverlays();
    initPoppers();
    initSelects();
    initComboboxes();
    initCommand();
    initToasts();
    initSliders();
    initDismiss();
    initConfirmGates();
    initTooltips();
    initIndeterminate();
    initScrollSpy();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
